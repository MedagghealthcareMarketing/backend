require("dotenv").config();

const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const axios = require("axios");
const helmet = require("helmet");
const morgan = require("morgan");
const path = require("path");

const app = express();

// Middleware setup
app.use(cors({
    origin: (origin, callback) => {
        // Allowed origins for production
        const allowedOrigins = [
            'https://services.medagghealthcare.com/', // frontend domain
            'http://localhost:5000', // for local development
        ];
        if (!origin || allowedOrigins.includes(origin)) {
            callback(null, true);
        } else {
            callback(new Error('Not allowed by CORS'));
        }
    },
}));
app.use(helmet());
app.use(morgan("combined")); // Logs requests in combined format
app.use(bodyParser.json());

// Access environment variables
const APIurl = process.env.TELECRM_API;
const TOKENno = process.env.TOKEN;
const PORT = process.env.PORT || 80; // Default to port 80 for production

console.log("API URL:", APIurl);
console.log("Token:", TOKENno);
console.log("Server Port:", PORT);

// Define routes
// Health check route
app.get("/health", (req, res) => {
    res.send("Backend is up and running!");
});

// TeleCRM POST endpoint
app.post("/api/telecrm", async (req, res) => {
    const { name, phone, sourceUrl } = req.body;

    // Construct payload
    const data = {
        fields: {
            name: name,
            phone: phone,
        },
        actions: [
            {
                type: "SYSTEM_NOTE",
                text: `Lead Source: ${sourceUrl}`, // Use dynamic source URL
            },
        ],
    };

    try {
        // Forward request to TeleCRM
        const response = await axios.post(APIurl, data, {
            headers: {
                Authorization: `Bearer ${TOKENno}`,
                "Content-Type": "application/json",
            },
        });

        // Respond back to frontend
        res.status(response.status).json(response.data);
    } catch (error) {
        console.error("Error with TeleCRM API:", error.message);
        res.status(error.response?.status || 500).json({
            message: error.response?.data || "Internal Server Error",
        });
    }
});

// Serve static files (Optional, if using static assets)
app.use(express.static(path.join(__dirname, "public")));

// Graceful shutdown handling
process.on("SIGINT", () => {
    console.log("Shutting down server...");
    process.exit(0);
});

process.on("SIGTERM", () => {
    console.log("Shutting down server...");
    process.exit(0);
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://server.medagghealthcare.com/:${PORT}`);
});
